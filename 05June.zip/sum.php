<?php echo "hello"; 
// error_reporting(0);
echo 2+2;

$a = 5;
$b = 20;

echo "<br> Static Sum is ";
echo $a+$b;
echo "<br> ";
// echo "<pre>";//<pre> preformated structured data
// print_r($_REQUEST); //print_r() developer option  

if (isset($_REQUEST['val1'])) {
    $dynamic_value1 = $_REQUEST['val1'];
    $dynamic_value2 = $_REQUEST['val2'];
    $dynamic_sum =$dynamic_value1+$dynamic_value2; 
    echo "Sum is ".$dynamic_sum;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- we can send client data to the server using form tag -->
    <!-- form tag has tow methods to send its data to the server-->
    <!-- GET -->
    <!-- its default method is get method -->
    <!-- get method sends data to the server using url by appending ? query string http://localhost/05June/regsitration.php?val1=21 -->
    <!-- get metghod is not secure -->
    <!-- get metghod has limitation to send data to the server is 2048 char only -->

    <!-- POST -->
    <!-- post method is secure  -->
    <!-- its doesnt have any limitations -->
    <form method="post">
        <input type="text" name="val1">
        <input type="text" name="val2">
        <input type="submit">
    </form>
</body>
</html>





