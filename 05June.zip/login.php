<?php

include_once('header.php');
// $Connection = new mysqli("hostName","username","password","databaseName");
// $Connection = new mysqli("localhost","root","","june05");
// echo "<pre>";
// print_r($Connection);

if (isset($_REQUEST['btn-login'])) {
    // echo "form Submitted";
    $SelectSQL = "SELECT * FROM users WHERE username='$_REQUEST[html_username]' AND password='$_REQUEST[html_password]'";

    $ExSQL = $Connection->query($SelectSQL);
    // print_r($ExSQL);
    // exit;
    // -> for access object data
    // [] use for the access array element
    if ($ExSQL->num_rows > 0) {
        $UserData = $ExSQL->fetch_object();
        // print_r($UserData);
        $_SESSION['UserData'] = $UserData;
        // echo "login Success";
        ?>
        <script>
            alert("Congratulations!!!");
            window.location.href="userhome.php";
        </script>
        <?php
    }else{
        echo "Invalid User!!!";
    }

}

?>

    <div class="row">
        <!-- <div class="col-md-4"></div> -->
        <div class="col-md-4 offset-md-4 mt-4">
            <div class="card border-secondary mb-3">
                <div class="card-header">Login Form</div>
                <div class="card-body">
                    <form  method="post">
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="text" class="form-control" name="html_username" placeholder="Enter User Name">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="password" class="form-control" name="html_password" placeholder="Enter Password">
                            </div>
                        </div>
                       
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="submit" class="btn btn-success" name="btn-login" value="Login" >
                                <input type="reset" class="btn btn-danger" value="Cancel" >
                                <br>
                                <a href="regsitration.php">Click here for the registration</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>    
</div>





</body>
</html>




