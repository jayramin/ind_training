<?php include_once('header.php'); 

if (isset($_REQUEST['delid'])) {
    $DeleteSQL = "DELETE FROM users WHERE userid='$_REQUEST[delid]'";
    $ExSQL = $Connection->query($DeleteSQL);
    if ($ExSQL > 0) {
        ?>
        <script>
            alert("Record Deleted Successfully");
            window.location.href="http://localhost/05June/userhome.php";
        </script>
        <?php
    }else{
        echo "Something Went wrong";
    }
}

?>
    <div class="row">
        <!-- <div class="col-md-4"></div> -->
        <div class="col-md-7 offset-md-3 mt-4">
            <div class="card border-secondary mb-3">
                <div class="card-header">All Users </div>
                <div class="card-body">
                    
                    
                    
                <table class="table table-striped table-bordered table-responsive">
                        <thead class="thead-light">
                            <tr>
                                <th>Sr.No </th>
                                <th>UserName </th>
                                <th>Mobile  </th>
                                <th>Email </th>
                                <th>Action </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                    
                    $SelectSQL = "SELECT * FROM users";
                    $ExSQL = $Connection->query($SelectSQL);
                    if ($ExSQL->num_rows > 0) { ?>
                    <?php while ($UserData = $ExSQL->fetch_object()) {
                            // print_r($UserData); ?>
                            <tr>
                                <td><?php echo $UserData->userid; ?></td>
                                <td><?php echo $UserData->username; ?></td>
                                <td><?php echo $UserData->mobile; ?></td>
                                <td><?php echo $UserData->email; ?></td>
                                <td>
                                    <a href="edit.php?editid=<?php echo $UserData->userid; ?>" class="btn btn-sm btn-info">Edit</a>
                                    <a href="userhome.php?delid=<?php echo $UserData->userid; ?>" class="btn btn-sm btn-danger">Delete</a>
                                </td>
                            </tr><?php
                        }
                     } ?>
                    
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>    
</div>





</body>
</html>




