<?php

include_once('header.php');
if (isset($_REQUEST['editid'])) {

    $SelectSQL = "SELECT * FROM users WHERE userid='$_REQUEST[editid]'";
    $ExSQL = $Connection->query($SelectSQL);
    if ($ExSQL->num_rows > 0) { 
        $UserData = $ExSQL->fetch_object();
        // echo "<pre>";
        // print_r($UserData);
    }   

    if (isset($_REQUEST['btn-update'])) {
       $UpdateSQL = "UPDATE users SET username='$_REQUEST[html_username]', password='$_REQUEST[html_password]', email='$_REQUEST[html_email]', mobile='$_REQUEST[html_mobile]' WHERE userid='$_REQUEST[editid]'";
       $ExSQL = $Connection->query($UpdateSQL);
        if ($ExSQL == 1) {
            echo "Data Updated Successfully";
            header("location:http://localhost/05June/userhome.php");
        }else{
            echo "Something went wrong!!!";
        }
    }

    // echo "form Submitted";
    // $InsertSQL = "INSERT INTO users (username,password,email,mobile) VALUES ('$_REQUEST[html_username]','$_REQUEST[html_password]','$_REQUEST[html_email]','$_REQUEST[html_mobile]')";

    // $ExSQL = $Connection->query($InsertSQL);
    // // print_r($ExSQL);
    // if ($ExSQL == 1) {
    //     echo "Data Inseted Successfully";
    //     // header("location:login.php");
    // }else{
    //     echo "Something went wrong!!!";
    // }

}

?>


    <div class="row">
        <!-- <div class="col-md-4"></div> -->
        <div class="col-md-4 offset-md-4 mt-4">
            <div class="card border-secondary mb-3">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-8">Edit User</div>
                        <div class="col-md-4"> <a class="btn btn-sm btn-outline-success" href="userhome.php">all Users</a> </div>
                    </div>
                     
                </div>
                <div class="card-body">
                    <form  method="post">
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="text" class="form-control" name="html_username" placeholder="Enter User Name" value="<?php echo $UserData->username ?>">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="password" class="form-control" name="html_password" placeholder="Enter Password" value="<?php echo $UserData->password ?>">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="email" class="form-control" name="html_email" placeholder="Enter email" value="<?php echo $UserData->email ?>">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="text" class="form-control" name="html_mobile" placeholder="Enter Mobile Nuber" value="<?php echo $UserData->mobile ?>">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="submit" class="btn btn-success" name="btn-update" value="Update" >
                                <input type="reset" class="btn btn-danger" value="Cancel" >
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>    
</div>





</body>
</html>




