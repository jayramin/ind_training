<?php

include_once('header.php');
// $Connection = new mysqli("hostName","username","password","databaseName");
// $Connection = new mysqli("localhost","root","","june05");
// echo "<pre>";
// print_r($Connection);

if (isset($_REQUEST['btn-regist'])) {
    // echo "form Submitted";
    $InsertSQL = "INSERT INTO users (username,password,email,mobile) VALUES ('$_REQUEST[html_username]','$_REQUEST[html_password]','$_REQUEST[html_email]','$_REQUEST[html_mobile]')";

    $ExSQL = $Connection->query($InsertSQL);
    // print_r($ExSQL);
    if ($ExSQL == 1) {
        echo "Data Inseted Successfully";
        // header("location:login.php");
        ?>
        <script>
            alert("Congratulations!!!");
            window.location.href="login.php";
        </script>
        <?php
    }else{
        echo "Something went wrong!!!";
    }

}

?>


    <div class="row">
        <!-- <div class="col-md-4"></div> -->
        <div class="col-md-4 offset-md-4 mt-4">
            <div class="card border-secondary mb-3">
                <div class="card-header">Registration Form</div>
                <div class="card-body">
                    <form  method="post">
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="text" class="form-control" name="html_username" placeholder="Enter User Name">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="password" class="form-control" name="html_password" placeholder="Enter Password">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="email" class="form-control" name="html_email" placeholder="Enter email">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="text" class="form-control" name="html_mobile" placeholder="Enter Mobile Nuber">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-12">
                                <input type="submit" class="btn btn-success" name="btn-regist" value="Regsiter" >
                                <input type="reset" class="btn btn-danger" value="Cancel" >
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>    
</div>





</body>
</html>




